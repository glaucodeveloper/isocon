# ISOCON — Bootstrap Web Components

Site estático B2B com páginas de início, segmentos, linhas, itens, logística, representantes, sobre, contato, solicitação e administração.

## Administração com PAT

Acesse `#/admin`. O GitHub Personal Access Token é a senha da área administrativa. O navegador valida o token no GitHub, exige permissão de escrita em `glaucodeveloper/isocon`, lê `data/catalog.json` e grava alterações pela Contents API.

Use um **fine-grained PAT** limitado ao repositório `glaucodeveloper/isocon`, com:

- Repository access: Only selected repositories → `isocon`
- Contents: Read and write
- Metadata: Read

O token não é incluído no build e fica apenas em `sessionStorage`. Como a aplicação é estática, o token digitado é usado diretamente no navegador para chamar a API do GitHub.

## Teste local

```bash
python3 -m http.server 8080
```

Abra `http://localhost:8080`.

## Envio inicial e deploy

```bash
chmod +x scripts/setup.sh scripts/deploy.sh
./scripts/setup.sh
```

Atualizações:

```bash
./scripts/deploy.sh "feat: atualiza catálogo"
```

Em **Settings → Pages**, selecione **GitHub Actions**. O workflow `.github/workflows/pages.yml` publica após cada push em `main`.
