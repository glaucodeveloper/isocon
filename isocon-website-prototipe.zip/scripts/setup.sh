#!/usr/bin/env bash
set -euo pipefail
REPO="${REPO:-https://github.com/glaucodeveloper/isocon.git}"
BRANCH="${BRANCH:-main}"
if [[ ! -d .git ]]; then
  git init
  git branch -M "$BRANCH"
  git remote add origin "$REPO"
fi
git add .
git commit -m "feat: cria website ISOCON em Bootstrap Web Components" || true
git push -u origin "$BRANCH"
echo "Push concluído. Ative GitHub Pages usando GitHub Actions."
