#!/usr/bin/env bash
set -euo pipefail
MESSAGE="${1:-chore: atualiza website ISOCON}"
git add .
if git diff --cached --quiet; then
  echo "Nenhuma alteração para publicar."
  exit 0
fi
git commit -m "$MESSAGE"
git push origin main
echo "Push concluído; pages.yml fará o deploy."
