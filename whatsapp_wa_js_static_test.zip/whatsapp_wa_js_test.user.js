// ==UserScript==
// @name         WhatsApp WA-JS — painel de teste
// @namespace    glauco.local
// @version      0.1.0
// @description  Painel experimental para enviar, observar e responder mensagens no WhatsApp Web.
// @match        https://web.whatsapp.com/*
// @require      https://cdn.jsdelivr.net/npm/@wppconnect/wa-js@4.4.2/dist/wppconnect-wa.js
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(() => {
  "use strict";

  const PANEL_ID = "glauco-wa-js-test-panel";
  const STORAGE_KEY = "glauco.waJsTest.settings.v1";
  const processedMessages = new Set();
  const lastReplyAt = new Map();

  const defaultSettings = {
    phone: "",
    message: "Olá! Esta é uma mensagem de teste enviada pelo WA-JS.",
    autoReply: false,
    includeGroups: false,
    keyword: "teste",
    fixedReply: "Recebi sua mensagem de teste.",
    inferenceEndpoint: "",
    cooldownSeconds: 5
  };

  function readSettings() {
    try {
      return {
        ...defaultSettings,
        ...JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}")
      };
    } catch {
      return { ...defaultSettings };
    }
  }

  function writeSettings(settings) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  }

  function idToString(value) {
    if (!value) return "";
    if (typeof value === "string") return value;
    if (value._serialized) return value._serialized;
    if (value.user && value.server) return `${value.user}@${value.server}`;
    return String(value);
  }

  function normalizeChatId(value) {
    const raw = String(value || "").trim();

    if (raw.includes("@")) {
      return raw;
    }

    const digits = raw.replace(/\D/g, "");
    if (!digits) {
      throw new Error("Informe o número com DDI e DDD.");
    }

    return `${digits}@c.us`;
  }

  function getMessageId(message) {
    return (
      idToString(message?.id?._serialized) ||
      idToString(message?.id) ||
      `${Date.now()}-${Math.random()}`
    );
  }

  function getMessageChatId(message) {
    return (
      idToString(message?.chatId) ||
      idToString(message?.from) ||
      idToString(message?.id?.remote)
    );
  }

  function getMessageBody(message) {
    return String(
      message?.body ??
      message?.caption ??
      message?.content ??
      ""
    ).trim();
  }

  function isFromMe(message) {
    return Boolean(message?.fromMe ?? message?.id?.fromMe);
  }

  function isGroup(chatId) {
    return chatId.endsWith("@g.us");
  }

  function isStatus(chatId) {
    return chatId === "status@broadcast";
  }

  function createElement(tag, attributes = {}, text = "") {
    const element = document.createElement(tag);

    for (const [name, value] of Object.entries(attributes)) {
      if (name === "class") {
        element.className = value;
      } else if (name === "type") {
        element.type = value;
      } else {
        element.setAttribute(name, value);
      }
    }

    if (text) {
      element.textContent = text;
    }

    return element;
  }

  function mountPanel() {
    const existing = document.getElementById(PANEL_ID);
    if (existing) {
      existing.hidden = false;
      return;
    }

    const settings = readSettings();
    const panel = createElement("aside", { id: PANEL_ID });

    panel.innerHTML = `
      <style>
        #${PANEL_ID} {
          position: fixed;
          z-index: 2147483647;
          top: 18px;
          right: 18px;
          width: min(390px, calc(100vw - 36px));
          max-height: calc(100vh - 36px);
          overflow: auto;
          box-sizing: border-box;
          padding: 16px;
          border: 1px solid rgba(255,255,255,.14);
          border-radius: 18px;
          background: #111b21;
          color: #e9edef;
          box-shadow: 0 24px 70px rgba(0,0,0,.48);
          font: 14px/1.4 system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        }

        #${PANEL_ID} * {
          box-sizing: border-box;
        }

        #${PANEL_ID} .wa-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          margin-bottom: 14px;
        }

        #${PANEL_ID} h2 {
          margin: 0;
          font-size: 17px;
        }

        #${PANEL_ID} .wa-close {
          width: 32px;
          height: 32px;
          border: 0;
          border-radius: 10px;
          background: #202c33;
          color: #e9edef;
          cursor: pointer;
        }

        #${PANEL_ID} .wa-status {
          margin-bottom: 14px;
          padding: 9px 11px;
          border-radius: 10px;
          background: #202c33;
          color: #aebac1;
          font-size: 12px;
        }

        #${PANEL_ID} .wa-grid {
          display: grid;
          gap: 10px;
        }

        #${PANEL_ID} label {
          display: grid;
          gap: 5px;
          color: #d1d7db;
          font-size: 12px;
        }

        #${PANEL_ID} input,
        #${PANEL_ID} textarea {
          width: 100%;
          border: 1px solid #374248;
          border-radius: 10px;
          outline: none;
          padding: 10px 11px;
          background: #202c33;
          color: #f0f2f5;
          font: inherit;
        }

        #${PANEL_ID} textarea {
          min-height: 72px;
          resize: vertical;
        }

        #${PANEL_ID} input:focus,
        #${PANEL_ID} textarea:focus {
          border-color: #00a884;
        }

        #${PANEL_ID} .wa-row {
          display: flex;
          gap: 8px;
          align-items: center;
        }

        #${PANEL_ID} .wa-row > * {
          flex: 1;
        }

        #${PANEL_ID} .wa-check {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 0;
          font-size: 13px;
        }

        #${PANEL_ID} .wa-check input {
          width: auto;
        }

        #${PANEL_ID} button.wa-primary,
        #${PANEL_ID} button.wa-secondary {
          min-height: 40px;
          border: 0;
          border-radius: 10px;
          padding: 0 13px;
          cursor: pointer;
          font: 600 13px/1 system-ui, sans-serif;
        }

        #${PANEL_ID} button.wa-primary {
          background: #00a884;
          color: #071b16;
        }

        #${PANEL_ID} button.wa-secondary {
          background: #202c33;
          color: #e9edef;
          border: 1px solid #374248;
        }

        #${PANEL_ID} .wa-divider {
          height: 1px;
          margin: 14px 0;
          background: #2a3942;
        }

        #${PANEL_ID} .wa-log {
          height: 150px;
          overflow: auto;
          padding: 10px;
          border-radius: 10px;
          background: #0b141a;
          color: #d1d7db;
          font: 11px/1.45 ui-monospace, SFMono-Regular, Consolas, monospace;
          white-space: pre-wrap;
          word-break: break-word;
        }

        #${PANEL_ID} .wa-note {
          color: #8696a0;
          font-size: 11px;
        }
      </style>

      <div class="wa-head">
        <h2>WA-JS — teste local</h2>
        <button class="wa-close" title="Fechar painel">×</button>
      </div>

      <div class="wa-status">Carregando WA-JS…</div>

      <div class="wa-grid">
        <label>
          Número de destino
          <input class="wa-phone" inputmode="tel" placeholder="5577999999999">
        </label>

        <label>
          Mensagem
          <textarea class="wa-message"></textarea>
        </label>

        <div class="wa-row">
          <button class="wa-primary wa-send">Enviar mensagem</button>
          <button class="wa-secondary wa-auth">Verificar sessão</button>
        </div>
      </div>

      <div class="wa-divider"></div>

      <div class="wa-grid">
        <label class="wa-check">
          <input class="wa-auto" type="checkbox">
          Responder mensagens recebidas
        </label>

        <label class="wa-check">
          <input class="wa-groups" type="checkbox">
          Permitir respostas em grupos
        </label>

        <label>
          Palavra necessária
          <input class="wa-keyword" placeholder="Vazio responde qualquer texto">
        </label>

        <label>
          Resposta fixa
          <textarea class="wa-fixed-reply"></textarea>
        </label>

        <label>
          Endpoint opcional de inferência
          <input class="wa-endpoint" type="url" placeholder="http://127.0.0.1:8000/infer">
        </label>

        <div class="wa-row">
          <label>
            Intervalo mínimo
            <input class="wa-cooldown" type="number" min="0" max="3600">
          </label>
          <span class="wa-note">segundos por conversa</span>
        </div>
      </div>

      <div class="wa-divider"></div>

      <div class="wa-log" aria-live="polite"></div>
      <p class="wa-note">
        O endpoint deve aceitar POST JSON e devolver texto puro ou JSON no formato
        <code>{"reply":"..."}</code>. Ele precisa permitir CORS para
        <code>https://web.whatsapp.com</code>.
      </p>
    `;

    document.body.appendChild(panel);

    const ui = {
      close: panel.querySelector(".wa-close"),
      status: panel.querySelector(".wa-status"),
      phone: panel.querySelector(".wa-phone"),
      message: panel.querySelector(".wa-message"),
      send: panel.querySelector(".wa-send"),
      auth: panel.querySelector(".wa-auth"),
      auto: panel.querySelector(".wa-auto"),
      groups: panel.querySelector(".wa-groups"),
      keyword: panel.querySelector(".wa-keyword"),
      fixedReply: panel.querySelector(".wa-fixed-reply"),
      endpoint: panel.querySelector(".wa-endpoint"),
      cooldown: panel.querySelector(".wa-cooldown"),
      log: panel.querySelector(".wa-log")
    };

    ui.phone.value = settings.phone;
    ui.message.value = settings.message;
    ui.auto.checked = settings.autoReply;
    ui.groups.checked = settings.includeGroups;
    ui.keyword.value = settings.keyword;
    ui.fixedReply.value = settings.fixedReply;
    ui.endpoint.value = settings.inferenceEndpoint;
    ui.cooldown.value = String(settings.cooldownSeconds);

    const log = (kind, message) => {
      const line = document.createElement("div");
      line.textContent = `[${new Date().toLocaleTimeString()}] ${kind}: ${message}`;
      ui.log.prepend(line);
    };

    const collectSettings = () => ({
      phone: ui.phone.value.trim(),
      message: ui.message.value,
      autoReply: ui.auto.checked,
      includeGroups: ui.groups.checked,
      keyword: ui.keyword.value.trim(),
      fixedReply: ui.fixedReply.value,
      inferenceEndpoint: ui.endpoint.value.trim(),
      cooldownSeconds: Math.max(0, Number(ui.cooldown.value) || 0)
    });

    const persist = () => writeSettings(collectSettings());

    panel.addEventListener("input", persist);
    panel.addEventListener("change", persist);

    ui.close.addEventListener("click", () => {
      panel.hidden = true;
    });

    ui.auth.addEventListener("click", async () => {
      try {
        const authenticated = await WPP.conn.isAuthenticated();
        ui.status.textContent = authenticated
          ? "Sessão autenticada e pronta."
          : "Sessão ainda não autenticada.";
        log("sessão", authenticated ? "autenticada" : "não autenticada");
      } catch (error) {
        log("erro", error?.message || String(error));
      }
    });

    ui.send.addEventListener("click", async () => {
      const originalText = ui.send.textContent;
      ui.send.disabled = true;
      ui.send.textContent = "Enviando…";

      try {
        const chatId = normalizeChatId(ui.phone.value);
        const text = ui.message.value.trim();

        if (!text) {
          throw new Error("Digite uma mensagem.");
        }

        await WPP.chat.sendTextMessage(chatId, text, {
          waitForAck: true,
          markIsRead: true
        });

        log("enviado", `${chatId}: ${text}`);
      } catch (error) {
        log("erro", error?.message || String(error));
      } finally {
        ui.send.disabled = false;
        ui.send.textContent = originalText;
      }
    });

    async function getAutomaticReply(body, chatId, currentSettings) {
      if (!currentSettings.inferenceEndpoint) {
        return currentSettings.fixedReply.trim();
      }

      const response = await fetch(currentSettings.inferenceEndpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          message: body,
          chatId,
          source: "whatsapp-web-wa-js"
        })
      });

      if (!response.ok) {
        throw new Error(`Inferência retornou HTTP ${response.status}.`);
      }

      const contentType = response.headers.get("content-type") || "";

      if (contentType.includes("application/json")) {
        const payload = await response.json();
        return String(
          payload.reply ??
          payload.response ??
          payload.message ??
          ""
        ).trim();
      }

      return (await response.text()).trim();
    }

    WPP.chat.on("chat.new_message", async (message) => {
      try {
        if (isFromMe(message)) return;

        const messageId = getMessageId(message);
        if (processedMessages.has(messageId)) return;
        processedMessages.add(messageId);

        if (processedMessages.size > 1000) {
          const first = processedMessages.values().next().value;
          processedMessages.delete(first);
        }

        const chatId = getMessageChatId(message);
        const body = getMessageBody(message);

        if (!chatId || !body || isStatus(chatId)) return;

        log("recebido", `${chatId}: ${body}`);

        const currentSettings = collectSettings();
        if (!currentSettings.autoReply) return;
        if (isGroup(chatId) && !currentSettings.includeGroups) return;

        const keyword = currentSettings.keyword.toLocaleLowerCase();
        if (keyword && !body.toLocaleLowerCase().includes(keyword)) return;

        const now = Date.now();
        const cooldownMs = currentSettings.cooldownSeconds * 1000;
        const previousReply = lastReplyAt.get(chatId) || 0;

        if (cooldownMs > 0 && now - previousReply < cooldownMs) {
          log("ignorado", `intervalo mínimo ativo para ${chatId}`);
          return;
        }

        const reply = await getAutomaticReply(body, chatId, currentSettings);
        if (!reply) {
          log("ignorado", "a inferência não retornou texto.");
          return;
        }

        await WPP.chat.sendTextMessage(chatId, reply, {
          waitForAck: true,
          markIsRead: true
        });

        lastReplyAt.set(chatId, Date.now());
        log("respondido", `${chatId}: ${reply}`);
      } catch (error) {
        log("erro automático", error?.message || String(error));
      }
    });

    WPP.on("conn.stream_mode_changed", (mode) => {
      ui.status.textContent = `Estado da conexão: ${mode}`;
      log("conexão", mode);
    });

    Promise.resolve(WPP.conn.isAuthenticated())
      .then((authenticated) => {
        ui.status.textContent = authenticated
          ? "WA-JS carregado; sessão autenticada."
          : "WA-JS carregado; leia o QR Code.";
        log("WA-JS", authenticated ? "pronto" : "aguardando autenticação");
      })
      .catch((error) => {
        ui.status.textContent = "WA-JS carregado; não foi possível consultar a sessão.";
        log("erro", error?.message || String(error));
      });
  }

  function waitForWpp() {
    if (window.WPP?.isReady) {
      mountPanel();
      return;
    }

    if (window.WPP?.loader?.onReady) {
      window.WPP.loader.onReady(mountPanel);
      return;
    }

    setTimeout(waitForWpp, 500);
  }

  waitForWpp();
})();
