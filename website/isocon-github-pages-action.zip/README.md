# GitHub Pages — ISOCON

Instala o workflow que publica somente o diretório `website/`.

## Aplicação

Na raiz do projeto `website-2`:

```bash
chmod +x install.sh
./install.sh "$PWD"
```

Depois:

```bash
git add .github/workflows/pages.yml website/.nojekyll
git commit -m "ci: publica website no GitHub Pages"
git push origin main
```

No repositório, abra:

```text
Settings → Pages → Build and deployment → Source → GitHub Actions
```

O deploy também pode ser iniciado manualmente pela aba **Actions**.
