#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$(git rev-parse --show-toplevel 2>/dev/null || pwd)}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

ROOT="$(cd "$ROOT" && pwd)"

if [[ ! -f "$ROOT/website/index.html" ]]; then
  echo "Erro: não encontrei:"
  echo "  $ROOT/website/index.html"
  echo
  echo "Execute na raiz website-2:"
  echo "  $0 \"$HOME/dev/ISOCON/website-2\""
  exit 1
fi

mkdir -p "$ROOT/.github/workflows"
cp "$SCRIPT_DIR/.github/workflows/pages.yml" \
   "$ROOT/.github/workflows/pages.yml"

touch "$ROOT/website/.nojekyll"

echo "Workflow instalado:"
echo "  $ROOT/.github/workflows/pages.yml"
echo
echo "Diretório publicado:"
echo "  $ROOT/website"
echo
echo "Envie com:"
echo "  cd \"$ROOT\""
echo "  git add .github/workflows/pages.yml website/.nojekyll"
echo '  git commit -m "ci: publica website no GitHub Pages"'
echo "  git push origin main"
